package com.example.aiassistant;

import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.ai.client.generativeai.type.GenerationConfig;
import java.util.ArrayList;
import java.util.List;

public class AIAssistantActivity extends AppCompatActivity {
    private RecyclerView chatRecyclerView;
    private EditText messageInput;
    private ImageButton sendButton;
    private ImageView backButton;
    private LinearLayout typingIndicator;
    private ChatAdapter chatAdapter;
    private List<MessageModel> messageList;
    
    // Gemini AI Configuration
    private static final String API_KEY = "AIzaSyBrKfeNqNWKyKT9ATtBQ24MTdn-xOvYC3c"; // Replace with your API key
    private GenerativeModel generativeModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_assistant);

        initializeViews();
        setupRecyclerView();
        setupGeminiAI();
        setupClickListeners();
        addWelcomeMessage();
    }

    private void initializeViews() {
        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);
        backButton = findViewById(R.id.backButton);
        typingIndicator = findViewById(R.id.typingIndicator);
        messageList = new ArrayList<>();
    }

    private void setupRecyclerView() {
        chatAdapter = new ChatAdapter(messageList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        chatRecyclerView.setLayoutManager(layoutManager);
        chatRecyclerView.setAdapter(chatAdapter);
    }

    private void setupGeminiAI() {
        // Configure Gemini AI for women's safety context
        GenerationConfig.Builder configBuilder = new GenerationConfig.Builder();
        configBuilder.temperature = 0.7f;
        configBuilder.topK = 40;
        configBuilder.topP = 0.95f;
        configBuilder.maxOutputTokens = 1024;

        generativeModel = new GenerativeModel(
            "gemini-pro",
            API_KEY,
            configBuilder.build()
        );
    }

    private void setupClickListeners() {
        sendButton.setOnClickListener(v -> sendMessage());
        
        messageInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage();
                return true;
            }
            return false;
        });

        backButton.setOnClickListener(v -> finish());
    }

    private void addWelcomeMessage() {
        String welcomeMessage = "Hi! I'm your personal safety assistant. I can help you with:\n\n" +
                "🛡️ Safety tips and guidelines\n" +
                "🚨 Emergency procedures\n" +
                "📱 App features guidance\n" +
                "🏃‍♀️ Self-defense advice\n" +
                "📍 Location safety tips\n\n" +
                "How can I help you stay safe today?";
        
        MessageModel welcomeMsg = new MessageModel(welcomeMessage, "bot");
        messageList.add(welcomeMsg);
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        scrollToBottom();
    }

    private void sendMessage() {
        String userMessage = messageInput.getText().toString().trim();
        if (userMessage.isEmpty()) return;

        // Add user message to chat
        MessageModel userMsg = new MessageModel(userMessage, "user");
        messageList.add(userMsg);
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        scrollToBottom();

        // Clear input and show typing indicator
        messageInput.setText("");
        showTypingIndicator(true);

        // Generate AI response
        generateAIResponse(userMessage);
    }

    private void generateAIResponse(String userMessage) {
        // Create safety-focused prompt
        String safetyPrompt = createSafetyPrompt(userMessage);
        
        new Thread(() -> {
            try {
                GenerateContentResponse response = generativeModel.generateContent(safetyPrompt);
                String aiResponse = response.getCandidates().get(0).getContent().getParts().get(0).asText();
                
                runOnUiThread(() -> {
                    showTypingIndicator(false);
                    
                    // Add AI response to chat
                    MessageModel botMsg = new MessageModel(aiResponse, "bot");
                    messageList.add(botMsg);
                    chatAdapter.notifyItemInserted(messageList.size() - 1);
                    scrollToBottom();
                });
                
            } catch (Exception e) {
                runOnUiThread(() -> {
                    showTypingIndicator(false);
                    showErrorMessage();
                });
                e.printStackTrace();
            }
        }).start();
    }

    private String createSafetyPrompt(String userMessage) {
        return "You are a helpful AI assistant specializing in women's safety and security. " +
               "Your role is to provide practical, actionable advice about personal safety, " +
               "emergency procedures, self-defense, and using safety apps. " +
               "Always prioritize user safety and provide encouraging, supportive responses. " +
               "If asked about topics unrelated to safety, gently redirect to safety topics. " +
               "Keep responses concise but comprehensive. " +
               "User question: " + userMessage;
    }

    private void showTypingIndicator(boolean show) {
        typingIndicator.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) scrollToBottom();
    }

    private void showErrorMessage() {
        MessageModel errorMsg = new MessageModel(
            "I'm sorry, I'm having trouble connecting right now. Please try again in a moment. " +
            "In case of emergency, always call your local emergency number immediately.", 
            "bot"
        );
        messageList.add(errorMsg);
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        scrollToBottom();
    }

    private void scrollToBottom() {
        if (messageList.size() > 0) {
            chatRecyclerView.smoothScrollToPosition(messageList.size() - 1);
        }
    }
}

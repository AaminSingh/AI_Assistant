package com.example.aiassistant;

class my {}